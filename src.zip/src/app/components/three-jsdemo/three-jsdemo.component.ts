import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RangeCustomEvent } from '@ionic/angular';
import { BoxGeometry, BufferAttribute, BufferGeometry, Clock, Mesh, MeshBasicMaterial, PerspectiveCamera, Scene, Texture, TextureLoader, WebGLRenderer } from 'three'

@Component({
  selector: 'app-three-jsdemo',
  templateUrl: './three-jsdemo.component.html',
  styleUrls: ['./three-jsdemo.component.scss'],
})
export class ThreeJSDemoComponent implements OnInit, AfterViewInit {
  @ViewChild('threejs')
  canvas!: ElementRef<HTMLCanvasElement>;
  scene!: Scene;
  camera!: PerspectiveCamera;
  renderer!: WebGLRenderer;
  cube!: Mesh<BoxGeometry, MeshBasicMaterial>
  rotationspeed = 0;
  clock = new Clock();
  map!: Mesh;

  constructor() { }

  ngOnInit() { }

  ngAfterViewInit() {
    this.scene = new Scene();
    this.camera = new PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.renderer = new WebGLRenderer({ canvas: this.canvas.nativeElement, antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);

    const geometry = new BoxGeometry(1, 1, 1);
    const material = new MeshBasicMaterial({ color: 0xffff00 });
    this.cube = new Mesh(geometry, material);
    this.cube.position.set(-5, 5, -5);
    this.scene.add(this.cube);

    this.camera.position.set(40,30, 40);
    this.camera.lookAt(0, 0, 0);

    const loader = new TextureLoader();
    loader.load('assets/maps/heightmap2.png', (texture: Texture) => this.onTextureLoaded(texture));

    this.renderer.setAnimationLoop(() => this.animate(10));
  }


  private onTextureLoaded(texture: Texture) {
    const canvas = document.createElement('canvas');
    canvas.width = texture.image.width;
    canvas.height = texture.image.height;

    const context = canvas.getContext('2d') as CanvasRenderingContext2D;
    context.drawImage(texture.image, 0, 0);

    const data = context.getImageData(0, 0, canvas.width, canvas.height);
    this.generateTerrain(data);
  }

  animate(total: number) {
    const elapsed = this.clock.getDelta();
    this.cube.rotation.x += (this.rotationspeed + 1) * 1 * elapsed;
    this.cube.rotation.y += (this.rotationspeed + 1) * 1 * elapsed;
    if (this.map){
    this.map.rotation.y += (this.rotationspeed + 1) * 0.05 * elapsed;
    }
    this.renderer.render(this.scene, this.camera);
  }

  onRotationSpeedChanged(event: Event) {
    const rangeEvent = event as RangeCustomEvent;
    this.rotationspeed = rangeEvent.detail.value as number;
  }

  private generateTerrain(pngData: ImageData) {
    const colorData = [[0.38, 0.68, 0.3], [0.8, 0.8, 0.3], [0.99, 0.99, 0.99], [0.2, 0.2, 0.5]];
    const vertices = [];

    const colors = [];
    for (let z = 0; z < pngData.height; z++) {
      for (let x = 0; x < pngData.width; x++) {
        const index = x * 4 + z * pngData.width * 4;
        const y = pngData.data[index] / 255;
        vertices.push(x - pngData.width / 2);
        vertices.push(y * 5);
        vertices.push(z - pngData.height / 2);
        if (y <= 0.1) {
          colors.push(...colorData[3], 1);
        } else if (y > 0.1 && y <= 0.5) {
          colors.push(...colorData[0], 1);
        }
        else if (y > 0.5 && y <= 0.8) {
          colors.push(...colorData[1], 1);
        } else {
          colors.push(...colorData[2], 1);
        }
      }
    }
    const indices = [];
    for (let i = 0; i < pngData.height - 1; i++) {
      const offset = i * pngData.width;
      for (let j = offset; j < offset + pngData.width - 1; j++) {
        indices.push(j);
        indices.push(j + pngData.width);
        indices.push(j + 1);

        indices.push(j + 1);
        indices.push(j + pngData.width);
        indices.push(j + 1 + pngData.width);
      }
    }
    const geometry = new BufferGeometry();
    geometry.setIndex(indices);
    geometry.setAttribute('position', new BufferAttribute(new Float32Array(vertices), 3));
    geometry.setAttribute('color', new BufferAttribute(new Float32Array(colors), 4));

    const material = new MeshBasicMaterial();
    material.vertexColors = true;
    material.wireframe = true;

    this.map = new Mesh(geometry, material);
    this.scene.add(this.map);

  }

}
